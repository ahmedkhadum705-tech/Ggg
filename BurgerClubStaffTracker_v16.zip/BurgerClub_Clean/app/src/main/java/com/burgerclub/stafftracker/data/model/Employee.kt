package com.burgerclub.stafftracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val hourlyRate: Double,
    val pinCode: String,
    val shiftStartTime: String = "00:00",
    val isOnShift: Boolean = false
)

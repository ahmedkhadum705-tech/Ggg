package com.burgerclub.stafftracker.ui.employees

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.burgerclub.stafftracker.R
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import java.util.concurrent.Executors

class EmployeeEditActivity : AppCompatActivity() {

    private var employeeId: Long = -1L
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_edit)

        employeeId = intent.getLongExtra("employee_id", -1L)

        try {
            val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
            setSupportActionBar(toolbar)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            toolbar.title = if (employeeId != -1L) "Редактировать" else "Новый сотрудник"
        } catch (e: Exception) { }

        if (employeeId != -1L) {
            executor.execute {
                try {
                    val emp = AppDatabase.getDatabase(this).employeeDao().getEmployee(employeeId)
                    emp?.let {
                        handler.post {
                            try {
                                findViewById<EditText>(R.id.etName)?.setText(it.name)
                                findViewById<EditText>(R.id.etRate)?.setText(it.hourlyRate.toInt().toString())
                                findViewById<EditText>(R.id.etPin)?.setText(it.pinCode)
                            } catch (e: Exception) { }
                        }
                    }
                } catch (e: Exception) { }
            }
        }

        findViewById<Button>(R.id.btnSave)?.setOnClickListener {
            val name = findViewById<EditText>(R.id.etName)?.text?.toString()?.trim() ?: ""
            val rateStr = findViewById<EditText>(R.id.etRate)?.text?.toString()?.trim() ?: ""
            val pin = findViewById<EditText>(R.id.etPin)?.text?.toString()?.trim() ?: ""

            if (name.isEmpty()) { Toast.makeText(this, "Введите имя", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (rateStr.isEmpty()) { Toast.makeText(this, "Введите ставку", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val rate = rateStr.toDoubleOrNull() ?: run { Toast.makeText(this, "Неверная ставка", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (pin.length < 4) { Toast.makeText(this, "PIN минимум 4 цифры", Toast.LENGTH_SHORT).show(); return@setOnClickListener }

            val emp = Employee(
                id = if (employeeId == -1L) 0L else employeeId,
                name = name,
                hourlyRate = rate,
                pinCode = pin,
                shiftStartTime = "00:00",
                isOnShift = false
            )

            executor.execute {
                try {
                    val db = AppDatabase.getDatabase(this)
                    if (employeeId == -1L) db.employeeDao().insert(emp)
                    else db.employeeDao().update(emp)
                    handler.post {
                        Toast.makeText(this, "✅ Сохранено", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } catch (e: Exception) {
                    handler.post {
                        Toast.makeText(this, "Ошибка БД: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}

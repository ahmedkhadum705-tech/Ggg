package com.burgerclub.stafftracker.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.burgerclub.stafftracker.data.model.Employee

@Dao
interface EmployeeDao {

    @Query("SELECT * FROM employees ORDER BY name ASC")
    fun getAllEmployees(): LiveData<List<Employee>>

    @Query("SELECT * FROM employees ORDER BY name ASC")
    suspend fun getAllEmployeesList(): List<Employee>

    @Query("SELECT * FROM employees WHERE id = :id")
    suspend fun getEmployee(id: Long): Employee?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(employee: Employee): Long

    @Update
    suspend fun update(employee: Employee)

    @Delete
    suspend fun delete(employee: Employee)

    @Query("UPDATE employees SET isOnShift = :isOnShift WHERE id = :id")
    suspend fun updateShiftStatus(id: Long, isOnShift: Boolean)
}

package com.burgerclub.stafftracker.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.data.model.ShiftRecord

@Database(
    entities = [Employee::class, ShiftRecord::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun employeeDao(): EmployeeDao
    abstract fun shiftRecordDao(): ShiftRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Migration from v1 to v2 - no schema change needed
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // shiftStartTime already exists, just keep it
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "burger_club_db"
                )
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration() // if migration fails, recreate DB
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.burgerclub.stafftracker.ui.employees

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.burgerclub.stafftracker.R
import com.burgerclub.stafftracker.data.db.AppDatabase
import com.burgerclub.stafftracker.data.model.Employee
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EmployeeEditActivity : AppCompatActivity() {

    private var employeeId: Long = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_edit)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        employeeId = intent.getLongExtra("employee_id", -1L)
        toolbar.title = if (employeeId != -1L) "Редактировать" else "Новый сотрудник"

        if (employeeId != -1L) loadEmployee()

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            saveEmployee()
        }
    }

    private fun loadEmployee() {
        CoroutineScope(Dispatchers.IO).launch {
            val emp = AppDatabase.getDatabase(this@EmployeeEditActivity)
                .employeeDao().getEmployee(employeeId) ?: return@launch
            withContext(Dispatchers.Main) {
                findViewById<EditText>(R.id.etName).setText(emp.name)
                findViewById<EditText>(R.id.etRate).setText(emp.hourlyRate.toInt().toString())
                findViewById<EditText>(R.id.etPin).setText(emp.pinCode)
            }
        }
    }

    private fun saveEmployee() {
        val name = findViewById<EditText>(R.id.etName).text.toString().trim()
        val rateStr = findViewById<EditText>(R.id.etRate).text.toString().trim()
        val pin = findViewById<EditText>(R.id.etPin).text.toString().trim()

        if (name.isEmpty()) {
            Toast.makeText(this, "Введите имя", Toast.LENGTH_SHORT).show()
            return
        }
        if (rateStr.isEmpty()) {
            Toast.makeText(this, "Введите ставку", Toast.LENGTH_SHORT).show()
            return
        }
        val rate = rateStr.toDoubleOrNull()
        if (rate == null || rate <= 0) {
            Toast.makeText(this, "Некорректная ставка", Toast.LENGTH_SHORT).show()
            return
        }
        if (pin.length < 4) {
            Toast.makeText(this, "PIN минимум 4 цифры", Toast.LENGTH_SHORT).show()
            return
        }

        val employee = Employee(
            id = if (employeeId == -1L) 0L else employeeId,
            name = name,
            hourlyRate = rate,
            pinCode = pin,
            shiftStartTime = "00:00",
            isOnShift = false
        )

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@EmployeeEditActivity).employeeDao().let {
                if (employeeId == -1L) it.insert(employee)
                else it.update(employee)
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@EmployeeEditActivity, "✅ Сохранено", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

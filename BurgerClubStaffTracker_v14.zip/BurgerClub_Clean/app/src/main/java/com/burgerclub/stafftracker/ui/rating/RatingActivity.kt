package com.burgerclub.stafftracker.ui.rating

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.burgerclub.stafftracker.data.repository.StaffRepository
import com.burgerclub.stafftracker.databinding.ActivityRatingBinding
import kotlinx.coroutines.launch

class RatingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRatingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRatingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.title = "🏆 Рейтинг сотрудников"

        val adapter = RatingAdapter()
        binding.rvRating.layoutManager = LinearLayoutManager(this)
        binding.rvRating.adapter = adapter

        lifecycleScope.launch {
            val ratings = StaffRepository(this@RatingActivity).getRatings()
            adapter.submitList(ratings)
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
